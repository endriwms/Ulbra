abstract class Jogador {
  public abstract void atacar();
  public abstract void defender();
}