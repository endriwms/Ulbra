public class Vendedor extends Funcionario {
  private String nome;
  private double salarioBase;
  private double comissao;

  public Vendedor(String nome, double salarioBase, double comissao) {
    this.nome = nome;
    this.salarioBase = salarioBase;
    this.comissao = comissao;
  }

  public double calcularSalario() {
    return salarioBase + comissao;
  }

  public void realizarTarefa() {
    System.out.println("Vendedor " + nome + " está realizando suas tarefas.");
  }
}