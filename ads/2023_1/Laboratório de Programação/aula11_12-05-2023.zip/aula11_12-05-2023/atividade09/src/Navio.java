public class Navio extends Transporte {
  public void carregar() {
    System.out.println("Carregando o navio...");
  }

  public void descarregar() {
    System.out.println("Descarregando o navio...");
  }
}