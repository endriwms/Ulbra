public class Caminhao extends Transporte {
  public void carregar() {
    System.out.println("Carregando o caminhão...");
  }

  public void descarregar() {
    System.out.println("Descarregando o caminhão...");
  }
}