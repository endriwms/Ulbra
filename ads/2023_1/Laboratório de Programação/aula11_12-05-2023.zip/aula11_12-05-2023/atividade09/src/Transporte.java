public abstract class Transporte {
  public abstract void carregar();
  public abstract void descarregar();
}