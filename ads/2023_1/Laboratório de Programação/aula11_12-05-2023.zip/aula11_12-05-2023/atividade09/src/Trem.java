public class Trem extends Transporte {
  public void carregar() {
    System.out.println("Carregando o trem...");
  }

  public void descarregar() {
    System.out.println("Descarregando o trem...");
  }
}