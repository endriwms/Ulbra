public class ImpressoraLaser extends Impressora {
  public void imprimir() {
    System.out.println("Imprimindo com impressora laser...");
  }

  public void escanear() {
    System.out.println("Escaneando com impressora laser...");
  }
}