public class ImpressoraJatoDeTinta extends Impressora {
  public void imprimir() {
    System.out.println("Imprimindo com impressora jato de tinta...");
  }

  public void escanear() {
    System.out.println("Escaneando com impressora jato de tinta...");
  }
}