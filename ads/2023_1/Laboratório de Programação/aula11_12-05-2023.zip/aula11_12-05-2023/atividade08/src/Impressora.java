public abstract class Impressora {
  public abstract void imprimir();
  public abstract void escanear();
}