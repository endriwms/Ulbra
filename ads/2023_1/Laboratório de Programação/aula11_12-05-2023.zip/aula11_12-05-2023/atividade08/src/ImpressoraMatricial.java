public class ImpressoraMatricial extends Impressora {
  public void imprimir() {
    System.out.println("Imprimindo com impressora matricial...");
  }

  public void escanear() {
    System.out.println("Não é possível escanear com impressora matricial.");
  }
}