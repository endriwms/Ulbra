public class PenDrive extends DispositivoArmazenamento {
  public void lerDados() {
    System.out.println("Lendo dados do pen drive...");
  }

  public void gravarDados() {
    System.out.println("Gravando dados no pen drive...");
  }
}