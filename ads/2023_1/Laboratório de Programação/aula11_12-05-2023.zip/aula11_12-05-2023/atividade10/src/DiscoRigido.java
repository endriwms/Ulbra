public class DiscoRigido extends DispositivoArmazenamento {
  public void lerDados() {
    System.out.println("Lendo dados do disco rígido...");
  }

  public void gravarDados() {
    System.out.println("Gravando dados no disco rígido...");
  }
}