public class CartaoSD extends DispositivoArmazenamento {
  public void lerDados() {
    System.out.println("Lendo dados do cartão SD...");
  }

  public void gravarDados() {
    System.out.println("Gravando dados no cartão SD...");
  }
}