public abstract class DispositivoArmazenamento {
  public abstract void lerDados();
  public abstract void gravarDados();
}
