abstract class Arquivo {
  public abstract void abrir();
  public abstract void fechar();
}