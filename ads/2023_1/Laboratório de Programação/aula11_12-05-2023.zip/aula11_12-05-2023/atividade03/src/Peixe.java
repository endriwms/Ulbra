class Peixe extends Animal {
  public void comer() {
    System.out.println("O peixe está se alimentando.");
  }

  public void dormir() {
    System.out.println("O peixe está descansando.");
  }

  public void mover() {
    System.out.println("O peixe está nadando.");
  }
}