class Cachorro extends Animal {
  public void comer() {
    System.out.println("O cachorro está comendo.");
  }

  public void dormir() {
    System.out.println("O cachorro está dormindo.");
  }

  public void mover() {
    System.out.println("O cachorro está se movendo.");
  }
}
