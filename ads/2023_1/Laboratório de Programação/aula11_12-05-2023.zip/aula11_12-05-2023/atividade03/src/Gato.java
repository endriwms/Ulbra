class Gato extends Animal {
  public void comer() {
    System.out.println("O gato está comendo.");
  }

  public void dormir() {
    System.out.println("O gato está dormindo.");
  }

  public void mover() {
    System.out.println("O gato está se movendo.");
  }
}