abstract class Produto {
  public abstract double calcularPreco();
  public abstract void exibirDetalhes();
}