create definer = root@`%` trigger atualiza_estoque_orcamentos_produtos
    after insert
    on Orcamentos_produtos
    for each row
BEGIN
    IF NEW.status = 'Disponível' THEN
        UPDATE Produtos SET qtd_estoque = qtd_estoque - NEW.qtd WHERE id_produtos = NEW.id_produtos;
    ELSEIF NEW.status = 'Indisponível' OR NEW.status = 'Cancelado' THEN
        UPDATE Produtos SET qtd_estoque = qtd_estoque + NEW.qtd WHERE id_produtos = NEW.id_produtos;
    END IF;
END;

