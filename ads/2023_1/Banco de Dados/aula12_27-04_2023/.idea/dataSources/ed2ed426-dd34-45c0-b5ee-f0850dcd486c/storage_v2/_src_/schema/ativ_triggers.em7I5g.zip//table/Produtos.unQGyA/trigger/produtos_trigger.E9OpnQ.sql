create definer = root@`%` trigger produtos_trigger
    before update
    on Produtos
    for each row
BEGIN
    DECLARE qtd_anterior INT;
    DECLARE qtd_atualizada INT;

    IF NEW.qtd_estoque = 0 THEN
        INSERT INTO produtos_em_falta (descricao, status, falta) VALUES (NEW.descricao, NEW.status, NEW.falta);
        SET NEW.status = NULL;
        UPDATE Orcamentos_produtos SET status = NULL WHERE id_produtos = NEW.id_produtos;
    ELSE
        SET qtd_anterior = OLD.qtd_estoque;
        SET qtd_atualizada = NEW.qtd_estoque;
        INSERT INTO produtos_atualizados (prd_codigo, prd_qtd_anterior, prd_qtd_atualizada, prd_valor) VALUES (NEW.id_produtos, qtd_anterior, qtd_atualizada, NEW.valor);
    END IF;
END;

