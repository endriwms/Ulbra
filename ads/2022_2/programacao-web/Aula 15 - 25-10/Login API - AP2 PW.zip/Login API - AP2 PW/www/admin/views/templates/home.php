<h2>Home</h2>

<p>
    Bem vindo ao site <b><?=$_SESSION['user']['name']?></b>
</p>