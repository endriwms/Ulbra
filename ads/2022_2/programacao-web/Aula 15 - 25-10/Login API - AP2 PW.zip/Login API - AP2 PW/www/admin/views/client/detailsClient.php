<h1>Detalhes do Cliente</h1>

<table class="table table-striped">
    <tr>
        <th>Código Cliente</th>
        <td>
            <?= $arrayClient['idClient'] ?>
        </td>
    </tr>
    <tr>
        <th>Nome</th>
        <td>
            <?= $arrayClient['name'] ?>
        </td>
    </tr>
    <tr>
        <th>email</th>
        <td>
            <?= $arrayClient['email'] ?>
        </td>
    </tr>
    <tr>
        <th>telefone</th>
        <td>
            <?= $arrayClient['name'] ?>
        </td>
    </tr>
    <tr>
        <th>Endereço</th>
        <td>
            <?= $arrayClient['address'] ?>
        </td>
    </tr>
</table>