
<footer>
    <div class="bg-dark text-white text-center p-5">
        <h1>@lms.souza</h1>
    </div>
</footer>
</body>
</html>