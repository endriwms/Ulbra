<h1>Cadastro</h1>

<table>
  <tr>
    <th>Nome:</th>
    <td> <?= $arrayClient['name']?></td>
  </tr>
  <tr>
    <th>Email:</th>
    <td> <?= $arrayClient['email']?></td>
  </tr>

  <tr>
    <th>Gênero:</th>
    <td> <?= $arrayClient['gender']?></td>
  </tr>
  <tr>
    <th>Cor:</th>
    <td> <?= $arrayClient['color']?></td>
  </tr>
</table>