        </section>
            </div>
            
        </div>

        <footer class="text-center p-5">
            <h2>Meu rodapé</h2>
            <a id="areaAdmin" href="admin/index.php">Área administrativa</a>
        </footer>
    </body>
</html>