create definer = root@`%` view vw_ingressos_disponiveis as
select `i`.`id`                       AS `id`,
       `i`.`tipo`                     AS `tipo`,
       `i`.`preco`                    AS `preco`,
       count(`pa`.`id`)               AS `qtd_comprados`,
       `i`.`preco` * count(`pa`.`id`) AS `receita_total`
from (`ap1`.`ingresso` `i` left join `ap1`.`participacao` `pa`
      on (`pa`.`evento_id` = `i`.`evento_id` and `pa`.`esta_pago` = 1))
group by `i`.`id`;

