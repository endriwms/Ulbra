create
    definer = root@`%` procedure sp_participantes_nao_pagaram(IN p_evento_id int)
BEGIN
    SELECT participante.nome, participacao.esta_pago
    FROM participante
    INNER JOIN participacao ON participante.id = participacao.participante_id
    WHERE participacao.evento_id = p_evento_id AND participacao.esta_pago = 0;
END;

