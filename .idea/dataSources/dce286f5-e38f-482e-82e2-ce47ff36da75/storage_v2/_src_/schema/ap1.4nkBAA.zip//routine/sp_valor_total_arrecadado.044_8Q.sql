create
    definer = root@`%` procedure sp_valor_total_arrecadado(IN p_evento_id int)
BEGIN
    SELECT SUM(i.preco) AS valor_total
    FROM participacao p
    INNER JOIN ingresso i ON p.evento_id = i.evento_id
    WHERE i.evento_id = p_evento_id AND p.esta_pago = 1;
END;

