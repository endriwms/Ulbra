create
    definer = root@`%` procedure sp_quantidade_ingressos_vendidos(IN p_evento_id int)
BEGIN
    SELECT COUNT(*) AS quantidade
    FROM participacao p
    INNER JOIN ingresso i ON p.evento_id = i.evento_id
    WHERE i.evento_id = p_evento_id AND p.esta_pago = 1;
END;

