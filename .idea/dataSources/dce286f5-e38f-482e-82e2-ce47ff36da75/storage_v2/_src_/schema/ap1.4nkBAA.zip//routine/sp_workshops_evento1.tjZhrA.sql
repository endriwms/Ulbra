create
    definer = root@`%` procedure sp_workshops_evento1(IN p_evento_nome varchar(255))
BEGIN
    SELECT p.nome AS palestrante, w.titulo
    FROM palestrante p
    INNER JOIN workshop w
        ON p.id = w.palestrante_id
    RIGHT JOIN evento e
        ON w.evento_id = e.id
    WHERE e.nome = p_evento_nome;
END;

