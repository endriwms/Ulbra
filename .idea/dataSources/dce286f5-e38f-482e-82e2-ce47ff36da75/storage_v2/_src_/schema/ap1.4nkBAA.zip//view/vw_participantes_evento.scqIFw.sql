create definer = root@`%` view vw_participantes_evento as
select `p`.`id`    AS `id`,
       `p`.`nome`  AS `nome`,
       `p`.`email` AS `email`,
       `e`.`nome`  AS `nome_evento`,
       `e`.`data`  AS `data_evento`
from ((`ap1`.`participante` `p` join `ap1`.`participacao` `pa`
       on (`p`.`id` = `pa`.`participante_id`)) join `ap1`.`evento` `e` on (`e`.`id` = `pa`.`evento_id`));

