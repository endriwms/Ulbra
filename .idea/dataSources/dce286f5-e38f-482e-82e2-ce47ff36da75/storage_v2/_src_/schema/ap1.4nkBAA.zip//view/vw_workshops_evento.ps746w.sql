create definer = root@`%` view vw_workshops_evento as
select `w`.`id`        AS `id`,
       `w`.`titulo`    AS `titulo`,
       `w`.`descricao` AS `descricao`,
       `e`.`nome`      AS `nome_evento`,
       `p`.`nome`      AS `nome_palestrante`
from ((`ap1`.`workshop` `w` join `ap1`.`evento` `e` on (`e`.`id` = `w`.`evento_id`)) join `ap1`.`palestrante` `p`
      on (`p`.`id` = `w`.`palestrante_id`));

