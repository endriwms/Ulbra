create
    definer = root@`%` procedure sp_eventos_participante(IN p_participante_id int)
BEGIN
    SELECT e.nome, e.data, i.tipo
    FROM evento e
    INNER JOIN ingresso i ON e.id = i.evento_id
    INNER JOIN participacao p ON e.id = p.evento_id
    WHERE p.participante_id = p_participante_id;
END;

